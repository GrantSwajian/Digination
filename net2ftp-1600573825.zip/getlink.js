function getURL(){
     var link = window.location.href;
     document.getElementByID("pageLink").innerHTML = link;
}